/*
TODO: we need to check for new app version, download if it's available. 
Notify user about new version and ask if he want to update the app.
Right after he is telling that he want to do this we need to copy the app.
So far everything is automatic.
*/
module.exports = function(){
var updater = require('node-webkit-updater');
process.on("uncaughtException", function(e) { console.log(e); });
//var gui = require('nw.gui');
var pkg = require('./package.json');
window.pkg = pkg;
var copyPath, execPath;
var upd = new updater(pkg);
var newVersionCheckIntervalId = null;
var tryingForNewVersion = false;
var isDownloading = false;

console.log("IAM alive");
/*
1) check version update on start
2) if version is changed start updating 

1) check version update periodically
2) if version is updated, show update screen

*/

/*
if(gui.App.argv.length){
	copyPath = gui.App.argv[0];
	execPath = gui.App.argv[1];
}
*/
if(!copyPath){
  window.doVersion = function(){
    upd.checkNewVersion(versionChecked);
  }
	newVersionCheckIntervalId = setInterval(function(){
		if(!isDownloading && !tryingForNewVersion) {
          tryingForNewVersion = true; //lock
          upd.checkNewVersion(versionChecked);
          console.log("check ver");
        }
      }, 1000);
}else{
	upd.install(copyPath, newAppInstalled);

	function newAppInstalled(err){
		if(err){
			console.log(err);
			return;
		}
		upd.run(execPath, null);
//		gui.App.quit();
	}
}

function versionChecked(err, newVersionExists, manifest){
  tryingForNewVersion = false; //unlock
  console.log("checked", arguments);
  if(err){
  	console.log(err);
  	return Error(err);
  }
  else if(isDownloading){
  	console.log('Already downloading');
  	return;
  }
  else if(!newVersionExists){
  	console.log('No new version exists');
  	return;
  }
  if(window.setUpDownloadScreen) window.setUpDownloadScreen.call(this, manifest)
  isDownloading = true;
  clearInterval(newVersionCheckIntervalId);

  var loaded = 0;
  var newVersion = upd.download(function(error, filename){
  	newVersionDownloaded(error, filename, manifest);
  }, manifest);
  var perc = 0;
  
  window.onbeforeunload = function(){
    newVersion.abort();
  }
  newVersion.on('data', function(chunk){
  	loaded+=chunk.length;
    if(perc != Math.floor(loaded / newVersion['content-length'] * 100)){
      console.log("New version loading " + Math.floor(loaded / newVersion['content-length'] * 100) + '%');
      perc = Math.floor(loaded / newVersion['content-length'] * 100);
    }
    
  })
}
function newVersionDownloaded(err, filename, manifest){
  if(err){
    console.log(err)
    return Error(err);
  }
  console.log("unpacking: " + filename);
  setTimeout(function(){upd.unpack(filename, newVersionUnpacked, manifest);}, 1000)
}

function newVersionUnpacked(err, newAppPath){
  console.log("inside ver unpack");
  if(err){
    console.log(err)
    return Error(err);
  }
  console.log("about to run runInstaller");
  var runner = upd.runInstaller(newAppPath, [upd.getAppPath(), upd.getAppExec()]);
  console.log("quiting");
//  gui.App.quit();
}
}