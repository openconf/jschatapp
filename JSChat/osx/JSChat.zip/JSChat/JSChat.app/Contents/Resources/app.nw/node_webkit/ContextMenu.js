/*
* wrapper for lib
*/
(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(function () {
            return (root.ContextMenu = factory());
        });
    } else if (typeof exports === 'object') {
        // Node. Does not work with strict CommonJS, but
        // only CommonJS-like enviroments that support module.exports,
        // like Node.
        module.exports = factory();
    } else {
        // Browser globals
        root.ContextMenu = factory();
    }
}(this, function () {
    function Menu(cutLabel, copyLabel, pasteLabel) {
        var menu = new gui.Menu();

        var cut = new gui.MenuItem({
            label: cutLabel || "Cut"
            , click: function() {
              document.execCommand("cut");
              console.log('Menu:', 'cutted to clipboard');
          }
      })

        var copy = new gui.MenuItem({
            label: copyLabel || "Copy"
            , click: function() {
              document.execCommand("copy");
              console.log('Menu:', 'copied to clipboard');
          }
      })

        var paste = new gui.MenuItem({
            label: pasteLabel || "Paste"
            , click: function() {
              document.execCommand("paste");
              console.log('Menu:', 'pasted to textarea');
          }
      })
        ;

        menu.append(cut);
        menu.append(copy);
        menu.append(paste);

        return menu;
    }

    var menu = new Menu(/* pass cut, copy, paste labels if you need i18n*/);
    document.addEventListener("contextmenu", function(e) {
        menu.popup(e.x, e.y);
    });
    return menu;
}));